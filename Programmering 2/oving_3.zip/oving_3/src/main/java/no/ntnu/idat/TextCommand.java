package no.ntnu.idat;

public interface TextCommand {
  String execute(String text);

}